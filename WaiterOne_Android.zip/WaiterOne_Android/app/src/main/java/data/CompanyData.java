package data;

/**
 * Created by User on 6/21/2017.
 */
public class CompanyData {

    public int companyID;
    public String companyName;

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public int getCompanyID() {
        return companyID;
    }

    public String getCompanyName() {
        return companyName;
    }
}
