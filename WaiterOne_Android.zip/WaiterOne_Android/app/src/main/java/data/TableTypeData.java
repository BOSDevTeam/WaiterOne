package data;

/**
 * Created by NweYiAung on 14-02-2017.
 */
public class TableTypeData {

    int tableTypeID;
    String tableTypeName;

    public int getTableTypeID() {
        return tableTypeID;
    }

    public String getTableTypeName() {
        return tableTypeName;
    }

    public void setTableTypeID(int tableTypeID) {
        this.tableTypeID = tableTypeID;
    }

    public void setTableTypeName(String tableTypeName) {
        this.tableTypeName = tableTypeName;
    }
}
