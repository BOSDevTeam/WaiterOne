package data;

/**
 * Created by user on 5/13/2017.
 */
public class ReportData {
    String reportName;
    int reportID;

    public String getReportName() {
        return reportName;
    }

    public int getReportID() {
        return reportID;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public void setReportID(int reportID) {
        this.reportID = reportID;
    }
}
