package data;

/**
 * Created by NweYiAung on 14-02-2017.
 */
public class TasteData {

    int tasteid;
    String tasteName;

    public int getTasteid() {
        return tasteid;
    }

    public String getTasteName() {
        return tasteName;
    }

    public void setTasteid(int tasteid) {
        this.tasteid = tasteid;
    }

    public void setTasteName(String tasteName) {
        this.tasteName = tasteName;
    }
}
