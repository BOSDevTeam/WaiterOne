package data;

/**
 * Created by User on 8/23/2018.
 */
public class PaperWidthData {
    public int getWidthId() {
        return widthId;
    }

    public String getWidthName() {
        return widthName;
    }

    public void setWidthId(int widthId) {
        this.widthId = widthId;
    }

    public void setWidthName(String widthName) {
        this.widthName = widthName;
    }

    int widthId;
    String widthName;
}
