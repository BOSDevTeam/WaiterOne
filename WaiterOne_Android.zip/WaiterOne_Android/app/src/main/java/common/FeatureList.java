package common;

/**
 * Created by User on 8/9/2018.
 */
public class FeatureList {
    public static final String fOrderTime="Set Time in Order";
    public static final String fAutoTaste="Auto Popup Taste Dialog in Item Selection";
    public static final String fCustomerInfo="Set Customer Info";
    public static final String fBookingTable="Booking Table Feature";
    public static final String fTaxIncCharg="Tax(Include Charges)";
    public static final String fPrint2="Print(2)";
    public static final String fAutoPrint="Auto Printing (no print button)";
    public static final String fPaperConstrict="Print Paper Constriction";
    public static final String fUseMultiPrinter="Use Multi Printer";
    public static final String fPrintOrder="Print Order";
    public static final String fPrintButtonInSale="Show Print Button in Sale";
    public static final String fMultiTableBill="Multi Table Bill";
    public static final String fStartEndTime="Start Time - End Time";
    public static final String fUseItemImage="Use Item Image";
}
