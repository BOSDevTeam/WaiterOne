package common;

public class BTPrinterConnection {
}
