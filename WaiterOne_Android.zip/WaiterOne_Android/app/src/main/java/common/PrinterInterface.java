package common;

/**
 * Created by User on 8/17/2018.
 */
public class PrinterInterface {
    public static final String iEthernet="Ethernet";
    public static final String iBluetooth="Bluetooth";
    public static final String iUSB="USB";
}
