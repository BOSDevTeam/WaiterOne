package common;

public class PrintCount {
    public static final int cOne=1;
    public static final int cTwo=2;
    public static final int cThree=3;
}
