package common;

/**
 * Created by User on 8/17/2018.
 */
public class PaperWidth {
    public static final String w58="58 mm";
    public static final String w80="80 mm";
}
