package common;

/**
 * Created by User on 8/17/2018.
 */
public class PrinterModel {
    public static final String pEmpty="Choose Printer Model";
    public static final String pXPrinter="XPrinter XP-Q800(Ethernet)";
    public static final String pZy306="Zy306(Ethernet)";
    public static final String pOtherModel="Other model";
}
