package listener;

/**
 * Created by NweYiAung on 15-02-2017.
 */
public interface FeatureCheckListener {
    void onFeatureCheckedListener(int position);
    void onFeatureUnCheckedListener(int position);
}
