package listener;

public interface DeleteTranListBtnListener {
    void onDeleteClickListener(int position);
}
