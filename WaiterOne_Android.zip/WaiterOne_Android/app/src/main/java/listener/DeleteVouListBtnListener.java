package listener;

public interface DeleteVouListBtnListener {
    void onDetailClickListener(int position);
    void onDeleteClickListener(int position);
}
