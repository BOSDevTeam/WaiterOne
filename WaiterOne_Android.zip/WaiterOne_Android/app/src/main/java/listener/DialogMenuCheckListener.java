package listener;

/**
 * Created by NweYiAung on 14-02-2017.
 */
public interface DialogMenuCheckListener {

    void onMenuCheckedListener(int position);
    void onMenuUnCheckedListener(int position);
}
