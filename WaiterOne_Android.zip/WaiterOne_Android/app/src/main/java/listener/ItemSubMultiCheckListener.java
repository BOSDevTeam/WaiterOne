package listener;

public interface ItemSubMultiCheckListener {
    void onMultiCheckListener(int groupPosition,int position);
    void onMultiUnCheckListener(int groupPosition,int position);
}
