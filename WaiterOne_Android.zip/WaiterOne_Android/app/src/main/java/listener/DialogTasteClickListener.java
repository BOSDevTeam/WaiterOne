package listener;

/**
 * Created by NweYiAung on 14-02-2017.
 */
public interface DialogTasteClickListener {

    void onTasteClickListener(int position);
}
