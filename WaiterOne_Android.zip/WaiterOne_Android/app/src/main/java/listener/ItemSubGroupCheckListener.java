package listener;

public interface ItemSubGroupCheckListener {
    void onCheckListener(int position);
    void onUnCheckListener(int position);
    void onSubItemClickListener(int position);
}
