package listener;

/**
 * Created by NweYiAung on 01-03-2017.
 */
public interface SetupEditDeleteButtonClickListener {
    void onEditButtonClickListener(int position);
    void onDeleteButtonClickListener(int position);
}
