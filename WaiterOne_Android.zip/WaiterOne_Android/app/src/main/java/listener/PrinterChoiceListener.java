package listener;

public interface PrinterChoiceListener {
    void onPrinterChoiceListener(int position);
    void onPrinterUnChoiceListener(int position);
}
