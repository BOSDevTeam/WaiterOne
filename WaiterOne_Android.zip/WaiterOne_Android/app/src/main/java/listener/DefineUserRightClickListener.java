package listener;

/**
 * Created by User on 6/6/2017.
 */
public interface DefineUserRightClickListener {
    void onDefineButtonClickListener(int position);
}
