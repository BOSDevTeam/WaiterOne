package listener;

/**
 * Created by user on 5/13/2017.
 */
public interface ReportListClickListener {

    void onReportListClickListener(int position);
}
