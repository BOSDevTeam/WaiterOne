package listener;

/**
 * Created by NweYiAung on 21-02-2017.
 */
public interface BookingButtonClickListener {
    void onEditButtonClickListener(int position);
    void onDeleteButtonClickListener(int position);
}
