package listener;

public interface ItemImageButtonClickListener {
    void onOrderClickListener(int position);
}
