package listener;

public interface ItemSubSingleCheckListener {
    void onSingleCheckListener(int groupPosition,int position);
    void onSingleUnCheckListener(int groupPosition,int position);
}
