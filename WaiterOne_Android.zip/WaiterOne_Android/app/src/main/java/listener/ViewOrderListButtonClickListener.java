package listener;

/**
 * Created by NweYiAung on 13-03-2017.
 */
public interface ViewOrderListButtonClickListener {
    void onItemDeletedClickListener(int position);
}
