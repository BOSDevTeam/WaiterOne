package listener;

/**
 * Created by User on 6/5/2017.
 */
public interface ModuleCheckedListener {
    void onModuleCheckedListener(int position);
    void onModuleUnCheckedListener(int position);
}
