package com.bosictsolution.waiterone.util;

/**
 * Created by yefeng on 7/1/15.
 * github:yefengfreedom
 */
public class NoEvent {
}
